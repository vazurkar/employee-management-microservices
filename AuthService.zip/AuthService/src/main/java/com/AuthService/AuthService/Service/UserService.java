package com.AuthService.AuthService.Service;

import com.AuthService.AuthService.DTO.UserDto;
import com.AuthService.AuthService.Model.User;
import com.AuthService.AuthService.Repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }
    public UserDto saveUser(User user){
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        User savedUser = userRepository.save(user);

        return new UserDto(user.getId(), savedUser.getUsername(),savedUser.getEmail(), savedUser.getRole());

    }
}
